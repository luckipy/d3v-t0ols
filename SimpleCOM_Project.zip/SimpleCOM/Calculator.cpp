// ============================================================================
// Calculator.cpp - Implement COM object CCalculator
// ============================================================================
#include "SimpleCOM.h"

// ============================================================================
// CLASS: CCalculator
// - Implement IUnknown + ICalculator
// - Tự xóa bản thân khi reference count về 0
// ============================================================================
class CCalculator : public ICalculator
{
private:
    std::atomic<ULONG> m_refCount;   // Thread-safe ref count

public:
    CCalculator() : m_refCount(0)
    {
        // Khi object được tạo, tăng DLL ref count
        // Đảm bảo DLL không bị unload khi còn object đang sống
        ++g_dllRefCount;
    }

    virtual ~CCalculator()
    {
        // Object chết -> giảm DLL ref count
        --g_dllRefCount;
    }

    // ========================================================================
    // IUnknown - 3 method bắt buộc
    // ========================================================================

    // QueryInterface: "Mày có support interface X không?"
    // - Trả về S_OK + pointer nếu có
    // - Trả về E_NOINTERFACE nếu không
    HRESULT __stdcall QueryInterface(REFIID riid, void** ppv) override
    {
        if (ppv == nullptr)
            return E_POINTER;

        *ppv = nullptr;

        if (riid == IID_IUnknown)
        {
            // QUAN TRỌNG: phải cast rõ ràng để tránh ambiguity
            *ppv = static_cast<IUnknown*>(this);
        }
        else if (riid == IID_ICalculator)
        {
            *ppv = static_cast<ICalculator*>(this);
        }
        else
        {
            return E_NOINTERFACE;
        }

        // Trao pointer ra ngoài -> phải AddRef
        // Caller có trách nhiệm gọi Release() khi dùng xong
        AddRef();
        return S_OK;
    }

    // AddRef: Tăng reference count, trả về giá trị mới
    ULONG __stdcall AddRef() override
    {
        return ++m_refCount;
    }

    // Release: Giảm reference count
    // Khi về 0 -> object tự xóa mình (delete this)
    ULONG __stdcall Release() override
    {
        ULONG count = --m_refCount;
        if (count == 0)
        {
            delete this;  // Tự hủy - destructor sẽ giảm g_dllRefCount
        }
        return count;
    }

    // ========================================================================
    // ICalculator - Business logic
    // Luôn kiểm tra con trỏ output trước khi dereference
    // ========================================================================

    HRESULT __stdcall Add(long a, long b, long* pResult) override
    {
        if (pResult == nullptr) return E_POINTER;
        *pResult = a + b;
        return S_OK;
    }

    HRESULT __stdcall Subtract(long a, long b, long* pResult) override
    {
        if (pResult == nullptr) return E_POINTER;
        *pResult = a - b;
        return S_OK;
    }

    HRESULT __stdcall Multiply(long a, long b, long* pResult) override
    {
        if (pResult == nullptr) return E_POINTER;
        *pResult = a * b;
        return S_OK;
    }
};
