// ============================================================================
// ClassFactory.cpp - Implement IClassFactory cho CCalculator
//
// IClassFactory là "nhà máy" tạo ra COM object.
// COM runtime gọi DllGetClassObject để lấy factory,
// sau đó gọi factory->CreateInstance để tạo object thực sự.
// ============================================================================
#include "SimpleCOM.h"

// Forward declare CCalculator vì nó được định nghĩa trong Calculator.cpp
// Linker sẽ resolve khi link cả 2 .obj lại
// (Đã có trong SimpleCOM.h nhưng để rõ ràng hơn cho người đọc)

// ============================================================================
// CLASS: CCalculatorFactory
// Implement IClassFactory để tạo ra các instance của CCalculator
// ============================================================================
class CCalculatorFactory : public IClassFactory
{
private:
    std::atomic<ULONG> m_refCount;

public:
    CCalculatorFactory() : m_refCount(0) {}
    virtual ~CCalculatorFactory() {}

    // ========================================================================
    // IUnknown
    // ========================================================================
    HRESULT __stdcall QueryInterface(REFIID riid, void** ppv) override
    {
        if (ppv == nullptr) return E_POINTER;
        *ppv = nullptr;

        if (riid == IID_IUnknown || riid == IID_IClassFactory)
        {
            *ppv = static_cast<IClassFactory*>(this);
            AddRef();
            return S_OK;
        }
        return E_NOINTERFACE;
    }

    ULONG __stdcall AddRef() override
    {
        return ++m_refCount;
    }

    ULONG __stdcall Release() override
    {
        ULONG count = --m_refCount;
        if (count == 0)
            delete this;
        return count;
    }

    // ========================================================================
    // IClassFactory::CreateInstance
    //
    // Đây là method quan trọng nhất - tạo ra object CCalculator mới
    //
    // pOuter  : dùng cho COM Aggregation - chúng ta không support, return error
    // riid    : interface mà caller muốn nhận
    // ppv     : output - pointer đến interface
    // ========================================================================
    HRESULT __stdcall CreateInstance(
        IUnknown* pOuter,
        REFIID    riid,
        void**    ppv) override
    {
        if (ppv == nullptr) return E_POINTER;
        *ppv = nullptr;

        // Không hỗ trợ COM Aggregation trong ví dụ này
        if (pOuter != nullptr)
            return CLASS_E_NOAGGREGATION;

        // Tạo object mới - dùng std::nothrow để không throw exception
        // mà trả về nullptr nếu hết memory
        CCalculator* pCalc = new (std::nothrow) CCalculator();
        if (pCalc == nullptr)
            return E_OUTOFMEMORY;

        // QueryInterface sẽ tự AddRef nếu thành công
        HRESULT hr = pCalc->QueryInterface(riid, ppv);

        // Nếu QI thất bại (riid không được support), phải xóa object
        // vì không ai giữ reference đến nó
        if (FAILED(hr))
            delete pCalc;

        return hr;
    }

    // ========================================================================
    // IClassFactory::LockServer
    //
    // Giữ DLL trong memory kể cả khi không có object nào
    // fLock = TRUE  -> lock (tăng ref count)
    // fLock = FALSE -> unlock (giảm ref count)
    // ========================================================================
    HRESULT __stdcall LockServer(BOOL fLock) override
    {
        if (fLock)
            ++g_dllRefCount;
        else
            --g_dllRefCount;
        return S_OK;
    }
};

// ============================================================================
// DllGetClassObject - Export function #1
//
// COM runtime (SCM) gọi function này ngay sau khi LoadLibrary DLL.
// Mục đích: "Cho tao IClassFactory của CLSID X"
//
// STDAPI = extern "C" HRESULT __stdcall (để C linker không mangle tên)
// ============================================================================
STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, void** ppv)
{
    if (ppv == nullptr) return E_POINTER;
    *ppv = nullptr;

    if (rclsid == CLSID_Calculator)
    {
        CCalculatorFactory* pFactory = new (std::nothrow) CCalculatorFactory();
        if (pFactory == nullptr) return E_OUTOFMEMORY;

        HRESULT hr = pFactory->QueryInterface(riid, ppv);
        if (FAILED(hr))
            delete pFactory;
        return hr;
    }

    return CLASS_E_CLASSNOTAVAILABLE;
}

// ============================================================================
// DllCanUnloadNow - Export function #2
//
// COM runtime gọi định kỳ để hỏi: "Tao có thể FreeLibrary mày chưa?"
// Trả về S_OK nếu không còn object/lock nào -> safe to unload
// Trả về S_FALSE nếu vẫn còn object đang sống -> giữ lại
// ============================================================================
STDAPI DllCanUnloadNow()
{
    return (g_dllRefCount == 0) ? S_OK : S_FALSE;
}
