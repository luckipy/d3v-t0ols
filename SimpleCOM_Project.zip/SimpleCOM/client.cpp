// ============================================================================
// client.cpp - COM Client test application
//
// Build riêng thành EXE. Link với ole32.lib.
// Chạy SAU KHI đã regsvr32 SimpleCOM.dll
// ============================================================================

// INITGUID chỉ define ở 1 nơi duy nhất trong mỗi project.
// Client là project riêng nên define lại ở đây.
#define INITGUID
#include "SimpleCOM.h"
#include <combaseapi.h>   // CoInitialize, CoCreateInstance, CoUninitialize
#include <cstdio>         // printf

// Helper macro - in HRESULT dạng hex kèm mô tả
#define CHECK_HR(hr, msg) \
    if (FAILED(hr)) { \
        printf("[FAIL] %s  HRESULT=0x%08X\n", msg, (unsigned)hr); \
        goto cleanup; \
    } else { \
        printf("[ OK ] %s\n", msg); \
    }

int main()
{
    printf("=== SimpleCOM Calculator Client ===\n\n");

    HRESULT hr = S_OK;
    ICalculator* pCalc = nullptr;

    // -------------------------------------------------------------------------
    // Bước 1: CoInitialize - Khởi tạo COM apartment
    // nullptr = COINIT_APARTMENTTHREADED (STA) trên Windows
    // Phải gọi trước bất kỳ COM call nào khác
    // -------------------------------------------------------------------------
    hr = CoInitialize(nullptr);
    CHECK_HR(hr, "CoInitialize (khoi tao COM STA apartment)");

    // -------------------------------------------------------------------------
    // Bước 2: CoCreateInstance - Tạo COM object
    //
    // Đây là magic của COM: bạn chỉ cần biết CLSID và IID,
    // không cần biết DLL ở đâu hay class tên gì.
    // COM runtime tự tìm trong Registry và load DLL.
    //
    // CLSCTX_INPROC_SERVER = DLL chạy trong cùng process
    // (có thể là CLSCTX_LOCAL_SERVER cho EXE server khác process)
    // -------------------------------------------------------------------------
    hr = CoCreateInstance(
        CLSID_Calculator,       // Tạo class nào?
        nullptr,                // Không dùng aggregation
        CLSCTX_INPROC_SERVER,   // DLL trong cùng process
        IID_ICalculator,        // Muốn nhận interface nào?
        (void**)&pCalc          // Output: pointer đến ICalculator
    );
    CHECK_HR(hr, "CoCreateInstance (tao COM object)");

    // -------------------------------------------------------------------------
    // Bước 3: Dùng interface - gọi các method
    // -------------------------------------------------------------------------
    {
        long result = 0;

        printf("\n--- Phep tinh ---\n");

        hr = pCalc->Add(10, 20, &result);
        if (SUCCEEDED(hr)) printf("  10 + 20 = %ld\n", result);

        hr = pCalc->Subtract(50, 15, &result);
        if (SUCCEEDED(hr)) printf("  50 - 15 = %ld\n", result);

        hr = pCalc->Multiply(6, 7, &result);
        if (SUCCEEDED(hr)) printf("  6  x  7 = %ld\n", result);

        // QueryInterface: hỏi xem object có support IUnknown không
        // (luôn luôn có vì mọi COM object đều implement IUnknown)
        printf("\n--- QueryInterface demo ---\n");
        IUnknown* pUnk = nullptr;
        hr = pCalc->QueryInterface(IID_IUnknown, (void**)&pUnk);
        if (SUCCEEDED(hr)) {
            printf("  QueryInterface(IID_IUnknown) = OK (pointer: %p)\n", pUnk);
            pUnk->Release();
        }

        // Hỏi interface không tồn tại -> phải trả về E_NOINTERFACE
        IClassFactory* pFakeFactory = nullptr;
        hr = pCalc->QueryInterface(IID_IClassFactory, (void**)&pFakeFactory);
        printf("  QueryInterface(IID_IClassFactory) = 0x%08X %s\n",
            (unsigned)hr,
            hr == E_NOINTERFACE ? "(E_NOINTERFACE - dung!)" : "(khong mong doi)");
    }

cleanup:
    // -------------------------------------------------------------------------
    // Bước 4: Release - Giảm reference count
    // Khi refcount về 0, object tự xóa (delete this)
    // -------------------------------------------------------------------------
    if (pCalc)
    {
        printf("\n--- Cleanup ---\n");
        ULONG remaining = pCalc->Release();
        printf("  pCalc->Release() called. Remaining refs: %lu\n", remaining);
        pCalc = nullptr;  // Tránh dangling pointer
    }

    // -------------------------------------------------------------------------
    // Bước 5: CoUninitialize - Dọn dẹp COM
    // Phải gọi một lần cho mỗi lần CoInitialize thành công
    // -------------------------------------------------------------------------
    CoUninitialize();
    printf("  CoUninitialize() called.\n");

    printf("\n=== Done ===\n");
    return SUCCEEDED(hr) ? 0 : 1;
}
