# SimpleCOM - Hướng dẫn Build & Chạy

## Cấu trúc Project

```
SimpleCOM/
├── SimpleCOM.sln          ← Mở file này bằng Visual Studio
│
├── --- DLL Project (SimpleCOM.dll) ---
├── SimpleCOM.h            ← Interface + GUID definitions (include ở mọi nơi)
├── Calculator.cpp         ← CCalculator: implement IUnknown + ICalculator
├── ClassFactory.cpp       ← CCalculatorFactory + DllGetClassObject + DllCanUnloadNow
├── dllmain.cpp            ← DllMain + DllRegisterServer + DllUnregisterServer
├── SimpleCOM.def          ← Khai báo exported functions
├── SimpleCOM.vcxproj      ← Project file cho DLL
│
└── --- Client Project (SimpleClient.exe) ---
    ├── client.cpp         ← Test app dùng COM object
    └── SimpleClient.vcxproj
```

## Điểm quan trọng nhất trong code

### 1. INITGUID - Chỉ define ở MỘT file duy nhất
```cpp
// dllmain.cpp (cho DLL) và client.cpp (cho EXE) - mỗi project define 1 lần
#define INITGUID        // PHẢI đứng TRƯỚC #include "SimpleCOM.h"
#include "SimpleCOM.h"
```

### 2. Tại sao cần INITGUID?
- `DEFINE_GUID(CLSID_Calculator, ...)` trong header chỉ là `extern` declaration
- Khi có `#define INITGUID`, nó trở thành definition (cấp phát bộ nhớ thực)
- Nếu không có INITGUID -> linker error "unresolved external symbol CLSID_Calculator"
- Nếu define ở nhiều .cpp -> linker error "already defined"

### 3. g_dllRefCount - Global đúng 1 lần
- Định nghĩa trong `dllmain.cpp`: `std::atomic<ULONG> g_dllRefCount(0);`
- Khai báo `extern` trong `SimpleCOM.h` để các file khác dùng được

---

## Bước 1: Build

1. Mở `SimpleCOM.sln` bằng Visual Studio 2019/2022
2. Chọn platform **x64** (quan trọng - phải match với bitness của regsvr32)
3. Build Solution (`Ctrl+Shift+B`)
4. Output: `x64\Debug\SimpleCOM.dll` và `x64\Debug\SimpleClient.exe`

---

## Bước 2: Đăng ký DLL (chạy với quyền Administrator)

```bat
:: Mở Command Prompt as Administrator, sau đó:
cd C:\path\to\SimpleCOM\x64\Debug

:: Đăng ký
regsvr32 SimpleCOM.dll

:: Nếu thành công: "DllRegisterServer in SimpleCOM.dll succeeded."
```

**Kiểm tra registry sau khi đăng ký:**
```bat
reg query "HKCR\CLSID\{A1B2C3D4-E5F6-7890-ABCD-EF1234567890}" /s
reg query "HKCR\SimpleCOM.Calculator" /s
```

---

## Bước 3: Chạy Client

```bat
:: Không cần quyền Admin
SimpleClient.exe
```

**Output mong đợi:**
```
=== SimpleCOM Calculator Client ===

[ OK ] CoInitialize (khoi tao COM STA apartment)
[ OK ] CoCreateInstance (tao COM object)

--- Phep tinh ---
  10 + 20 = 30
  50 - 15 = 35
  6  x  7 = 42

--- QueryInterface demo ---
  QueryInterface(IID_IUnknown) = OK
  QueryInterface(IID_IClassFactory) = 0x80004002 (E_NOINTERFACE - dung!)

--- Cleanup ---
  pCalc->Release() called. Remaining refs: 0

=== Done ===
```

---

## Bước 4: Gỡ đăng ký khi không cần nữa

```bat
:: Chạy với quyền Administrator
regsvr32 /u SimpleCOM.dll
```

---

## Troubleshooting

| Lỗi | Nguyên nhân | Fix |
|-----|-------------|-----|
| `0x80040154 REGDB_E_CLASSNOTREG` | Chưa regsvr32 | Chạy `regsvr32 SimpleCOM.dll` |
| `0x80070005 E_ACCESSDENIED` | regsvr32 không có Admin rights | Chạy CMD as Administrator |
| `0x8002801C TYPE_E_REGISTRYACCESS` | Registry bị khóa | Kiểm tra antivirus / group policy |
| Linker: `unresolved CLSID_Calculator` | Thiếu INITGUID | Thêm `#define INITGUID` trước include |
| Linker: `already defined CLSID_Calculator` | INITGUID ở nhiều file | Chỉ giữ INITGUID ở 1 file mỗi project |

---

## Luồng hoạt động tóm tắt

```
SimpleClient.exe                    Registry              SimpleCOM.dll
      │                                 │                       │
      ├─ CoInitialize()                 │                       │
      │                                 │                       │
      ├─ CoCreateInstance(CLSID) ──────►│                       │
      │                        lookup ──┤                       │
      │                   InprocServer32 path ─────────────────►│
      │                                 │   LoadLibrary         │
      │                                 │   DllGetClassObject() │
      │                                 │   factory->CreateInstance()
      │  ◄── ICalculator* ──────────────┼───────────────────────┤
      │                                 │                       │
      ├─ pCalc->Add(10, 20, &result) ───┼──────────────────────►│
      │  ◄── result = 30 ───────────────┼───────────────────────┤
      │                                 │                       │
      ├─ pCalc->Release() ─────────────►│ (refcount=0, delete)  │
      │                                 │                       │
      └─ CoUninitialize()               │                       │
```
