#pragma once

// ============================================================================
// SimpleCOM.h - Header duy nhất cho toàn bộ project
// Include file này ở MỌI .cpp để có đầy đủ declarations
// ============================================================================

// --- Standard Windows / COM headers (thứ tự quan trọng) ---
#include <windows.h>        // HRESULT, ULONG, BOOL, WINAPI...
#include <unknwn.h>         // IUnknown, IClassFactory
#include <atomic>           // std::atomic
#include <new>              // std::nothrow

// ============================================================================
// GUID DEFINITIONS
// Dùng DEFINE_GUID thay vì khai báo thẳng để tránh "multiple definition"
// khi nhiều .cpp cùng include header này.
// INITGUID phải được define ở ĐÚNG MỘT .cpp (dllmain.cpp) trước khi include.
// ============================================================================

// {A1B2C3D4-E5F6-7890-ABCD-EF1234567890}
DEFINE_GUID(CLSID_Calculator,
    0xa1b2c3d4, 0xe5f6, 0x7890,
    0xab, 0xcd, 0xef, 0x12, 0x34, 0x56, 0x78, 0x90);

// {B2C3D4E5-F6A7-8901-BCDE-F12345678901}
DEFINE_GUID(IID_ICalculator,
    0xb2c3d4e5, 0xf6a7, 0x8901,
    0xbc, 0xde, 0xf1, 0x23, 0x45, 0x67, 0x89, 0x01);

// ============================================================================
// INTERFACE: ICalculator
// Kế thừa IUnknown - bắt buộc với mọi COM interface
// __stdcall - calling convention chuẩn COM (callee cleans stack)
// ============================================================================
struct ICalculator : public IUnknown
{
    virtual HRESULT __stdcall Add     (long a, long b, long* pResult) = 0;
    virtual HRESULT __stdcall Subtract(long a, long b, long* pResult) = 0;
    virtual HRESULT __stdcall Multiply(long a, long b, long* pResult) = 0;
};

// ============================================================================
// FORWARD DECLARATIONS - để ClassFactory.cpp biết CCalculator tồn tại
// ============================================================================
class CCalculator;
class CCalculatorFactory;

// ============================================================================
// GLOBAL DLL REFERENCE COUNT
// Dùng để COM runtime biết có unload DLL được chưa (DllCanUnloadNow)
// extern: định nghĩa thực sự nằm trong dllmain.cpp
// ============================================================================
extern std::atomic<ULONG> g_dllRefCount;
