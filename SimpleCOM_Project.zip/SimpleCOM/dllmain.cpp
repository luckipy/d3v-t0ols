// ============================================================================
// dllmain.cpp - DLL Entry Point + Registration
//
// QUAN TRỌNG: #define INITGUID PHẢI nằm trước #include "SimpleCOM.h"
// và CHỈ ở đúng 1 file .cpp duy nhất trong toàn project.
//
// Lý do: DEFINE_GUID() trong header chỉ khai báo (extern) nếu không có
// INITGUID. Khi có INITGUID, nó sẽ ĐỊNH NGHĨA (cấp phát bộ nhớ) cho GUID.
// Nếu define ở nhiều file -> linker error "already defined".
// ============================================================================
#define INITGUID                // Phải đứng TRƯỚC mọi include COM
#include "SimpleCOM.h"
#include <stdio.h>              // swprintf_s
#include <olectl.h>             // SELFREG_E_CLASS

// ============================================================================
// GLOBAL: DLL Reference Count
// - Được tăng khi tạo object mới (CCalculator constructor)
// - Được giảm khi object bị hủy (CCalculator destructor)
// - Được tăng/giảm bởi IClassFactory::LockServer
// ============================================================================
std::atomic<ULONG> g_dllRefCount(0);

// ============================================================================
// DLL Entry Point
// Windows gọi function này khi:
// - DLL được load vào process (DLL_PROCESS_ATTACH)
// - DLL bị unload (DLL_PROCESS_DETACH)
// - Thread mới tạo/hủy (DLL_THREAD_ATTACH/DETACH)
//
// hModule: handle của DLL này (cần để lấy đường dẫn file)
// ============================================================================
BOOL WINAPI DllMain(HINSTANCE hModule, DWORD dwReason, LPVOID /*lpReserved*/)
{
    switch (dwReason)
    {
    case DLL_PROCESS_ATTACH:
        // Lưu lại handle để dùng trong DllRegisterServer
        // DisableThreadLibraryCalls: tối ưu - không cần nhận
        // DLL_THREAD_ATTACH/DETACH notification
        DisableThreadLibraryCalls(hModule);
        break;

    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

// ============================================================================
// DllRegisterServer - Export function #3
//
// regsvr32.exe gọi function này để đăng ký COM server vào Registry.
// Chúng ta cần tạo các registry key sau:
//
// HKEY_CLASSES_ROOT\
//   CLSID\
//     {A1B2C3D4-E5F6-7890-ABCD-EF1234567890}\
//       (Default) = "SimpleCOM Calculator"
//       InprocServer32\
//         (Default)       = "C:\path\to\SimpleCOM.dll"
//         ThreadingModel  = "Apartment"
//   SimpleCOM.Calculator\         <- ProgID (human-friendly name)
//     (Default) = "SimpleCOM Calculator"
//     CLSID\
//       (Default) = "{A1B2C3D4-E5F6-7890-ABCD-EF1234567890}"
// ============================================================================
STDAPI DllRegisterServer()
{
    // Lấy đường dẫn đầy đủ của DLL này
    wchar_t dllPath[MAX_PATH] = {};
    HMODULE hThis = nullptr;

    // GetModuleHandleEx với GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS
    // giúp lấy handle của DLL hiện tại (không phải EXE)
    GetModuleHandleExW(
        GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
        GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
        (LPCWSTR)&DllRegisterServer,
        &hThis);
    GetModuleFileNameW(hThis, dllPath, MAX_PATH);

    const wchar_t* clsidStr  = L"{A1B2C3D4-E5F6-7890-ABCD-EF1234567890}";
    const wchar_t* friendlyName = L"SimpleCOM Calculator";
    const wchar_t* progID    = L"SimpleCOM.Calculator";

    HKEY  hKey  = nullptr;
    LONG  lRet  = ERROR_SUCCESS;
    HRESULT hr  = S_OK;

    // --- 1. HKCR\CLSID\{...} ---
    wchar_t clsidKeyPath[256] = {};
    swprintf_s(clsidKeyPath, 256, L"CLSID\\%s", clsidStr);

    lRet = RegCreateKeyExW(HKEY_CLASSES_ROOT, clsidKeyPath,
        0, nullptr, REG_OPTION_NON_VOLATILE, KEY_WRITE, nullptr, &hKey, nullptr);
    if (lRet != ERROR_SUCCESS) { hr = SELFREG_E_CLASS; goto cleanup; }

    // Set friendly name làm default value
    RegSetValueExW(hKey, nullptr, 0, REG_SZ,
        (const BYTE*)friendlyName, (DWORD)((wcslen(friendlyName) + 1) * sizeof(wchar_t)));
    RegCloseKey(hKey); hKey = nullptr;

    // --- 2. HKCR\CLSID\{...}\InprocServer32 ---
    wchar_t inprocKeyPath[256] = {};
    swprintf_s(inprocKeyPath, 256, L"CLSID\\%s\\InprocServer32", clsidStr);

    lRet = RegCreateKeyExW(HKEY_CLASSES_ROOT, inprocKeyPath,
        0, nullptr, REG_OPTION_NON_VOLATILE, KEY_WRITE, nullptr, &hKey, nullptr);
    if (lRet != ERROR_SUCCESS) { hr = SELFREG_E_CLASS; goto cleanup; }

    // Đường dẫn DLL
    RegSetValueExW(hKey, nullptr, 0, REG_SZ,
        (const BYTE*)dllPath, (DWORD)((wcslen(dllPath) + 1) * sizeof(wchar_t)));

    // Threading model - "Apartment" = STA
    const wchar_t* threadModel = L"Apartment";
    RegSetValueExW(hKey, L"ThreadingModel", 0, REG_SZ,
        (const BYTE*)threadModel, (DWORD)((wcslen(threadModel) + 1) * sizeof(wchar_t)));
    RegCloseKey(hKey); hKey = nullptr;

    // --- 3. HKCR\CLSID\{...}\ProgID ---
    wchar_t progIDKeyPath[256] = {};
    swprintf_s(progIDKeyPath, 256, L"CLSID\\%s\\ProgID", clsidStr);

    lRet = RegCreateKeyExW(HKEY_CLASSES_ROOT, progIDKeyPath,
        0, nullptr, REG_OPTION_NON_VOLATILE, KEY_WRITE, nullptr, &hKey, nullptr);
    if (lRet != ERROR_SUCCESS) { hr = SELFREG_E_CLASS; goto cleanup; }
    RegSetValueExW(hKey, nullptr, 0, REG_SZ,
        (const BYTE*)progID, (DWORD)((wcslen(progID) + 1) * sizeof(wchar_t)));
    RegCloseKey(hKey); hKey = nullptr;

    // --- 4. HKCR\SimpleCOM.Calculator ---
    lRet = RegCreateKeyExW(HKEY_CLASSES_ROOT, progID,
        0, nullptr, REG_OPTION_NON_VOLATILE, KEY_WRITE, nullptr, &hKey, nullptr);
    if (lRet != ERROR_SUCCESS) { hr = SELFREG_E_CLASS; goto cleanup; }
    RegSetValueExW(hKey, nullptr, 0, REG_SZ,
        (const BYTE*)friendlyName, (DWORD)((wcslen(friendlyName) + 1) * sizeof(wchar_t)));
    RegCloseKey(hKey); hKey = nullptr;

    // --- 5. HKCR\SimpleCOM.Calculator\CLSID ---
    wchar_t progIDClsidPath[256] = {};
    swprintf_s(progIDClsidPath, 256, L"%s\\CLSID", progID);

    lRet = RegCreateKeyExW(HKEY_CLASSES_ROOT, progIDClsidPath,
        0, nullptr, REG_OPTION_NON_VOLATILE, KEY_WRITE, nullptr, &hKey, nullptr);
    if (lRet != ERROR_SUCCESS) { hr = SELFREG_E_CLASS; goto cleanup; }
    RegSetValueExW(hKey, nullptr, 0, REG_SZ,
        (const BYTE*)clsidStr, (DWORD)((wcslen(clsidStr) + 1) * sizeof(wchar_t)));
    RegCloseKey(hKey); hKey = nullptr;

cleanup:
    if (hKey) RegCloseKey(hKey);
    return hr;
}

// ============================================================================
// DllUnregisterServer - Export function #4
//
// regsvr32 /u gọi function này để xóa tất cả registry keys đã tạo
// ============================================================================
STDAPI DllUnregisterServer()
{
    const wchar_t* clsidStr = L"{A1B2C3D4-E5F6-7890-ABCD-EF1234567890}";
    const wchar_t* progID   = L"SimpleCOM.Calculator";

    wchar_t clsidKeyPath[256] = {};
    swprintf_s(clsidKeyPath, 256, L"CLSID\\%s", clsidStr);

    // RegDeleteTree xóa key và toàn bộ subkeys/values bên trong
    RegDeleteTreeW(HKEY_CLASSES_ROOT, clsidKeyPath);
    RegDeleteTreeW(HKEY_CLASSES_ROOT, progID);

    return S_OK;
}
